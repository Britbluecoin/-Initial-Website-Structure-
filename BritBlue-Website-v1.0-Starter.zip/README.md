# British Blue Coin Website v1.0

Starter website structure.