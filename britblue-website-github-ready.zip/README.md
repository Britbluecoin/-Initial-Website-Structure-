# British Blue Coin — $BritBlue

Official website files for British Blue Coin.

## Structure

- `index.html` — Home
- `about.html` — Barnaby and the project story
- `litepaper.html` — Project litepaper
- `roadmap.html` — Roadmap
- `charity.html` — Charity mission
- `links.html` — Official links
- `faq.html` — Frequently asked questions
- `css/style.css` — Site styling
- `js/script.js` — Mobile navigation
- `assets/` — Images and artwork

## GitHub Pages

This is a static HTML website and can be published with GitHub Pages.

1. Upload all files to the repository root.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the main branch and `/ (root)`.
5. Save.

## Important before launch

Replace the placeholder assets with the final approved BritBlue logo, Barnaby/Jojo artwork and favicon.

Before publishing, verify every official social URL, wallet address, contract address and launch link. Do not publish an unverified contract or wallet address.

The content is informational only and is not financial, investment, tax or legal advice.
